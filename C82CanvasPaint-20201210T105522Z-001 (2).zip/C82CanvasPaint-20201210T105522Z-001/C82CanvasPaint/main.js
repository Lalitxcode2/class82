var mouseE = "empty";
var last_x,last_y;


canvas = document.getElementById("canvas");
ctx = canvas.getContext("2d");

color = "blue";

line_width = 2;

canvas.addEventListener("mousedown",M_D);
function M_D(q)
{
    mouseE = "mouseDown";
}

canvas.addEventListener("mouseup",M_U);
function M_U(q)
{
    mouseE = "mouseUP";
}

canvas.addEventListener("mouseleave",M_L);
function M_L(q)
{
    mouseE = "mouseleave";
}

canvas.addEventListener("mousemove",M_M);
function M_M(q)
{
    mouse_X = q.clientX - canvas.offsetLeft;
    mouse_Y = q.clientY - canvas.offsetTop;
    if(mouseE == "mousedown"){
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = line_width;

        console.log("Last position of X and Y coordinates = ");
        console.log(" X = "+ last_x + " Y = "+ last_y);
        ctx.moveTo(last_x,last_y);

        console.log("Current position of X and Y coordinates = ");
        console.log(" X = "+ mouse_X + " Y = "+ mouse_Y);
        ctx.lineTo(mouse_X,mouse_Y);
        ctx.stroke();
}
last_x = mouse_X;
last_y = mouse_Y;
}


